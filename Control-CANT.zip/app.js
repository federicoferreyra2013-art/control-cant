const KEY="control-cant-v1";
const PEOPLE_KEY="control-cant-people";
let people=JSON.parse(localStorage.getItem(PEOPLE_KEY)||"null") || [
  "Comandero",
  "Operador 1",
  "Operador 2",
  "Chofer 1",
  "Chofer 2"
];
let state=JSON.parse(localStorage.getItem(KEY)||"{}");
let deferredPrompt=null;

const $=id=>document.getElementById(id);
const today=()=>new Date().toISOString().slice(0,10);
$("fecha").value=today();

function dayKey(){return $("fecha").value+"_"+$("turno").value}
function marked(){return state[dayKey()]?.marked||[]}
function saveState(){localStorage.setItem(KEY,JSON.stringify(state))}
function savePeople(){localStorage.setItem(PEOPLE_KEY,JSON.stringify(people))}

function render(){
  const m=marked();
  $("people").innerHTML="";
  people.forEach((name,i)=>{
    const b=document.createElement("button");
    b.className="person"+(m.includes(name)?" checked":"");
    b.innerHTML=`${escapeHtml(name)} <span class="mark">${m.includes(name)?"✓":"○"}</span>`;
    b.onclick=()=>toggle(name);
    b.oncontextmenu=e=>{e.preventDefault(); removePerson(i)};
    $("people").appendChild(b);
  });
  $("total").textContent=people.length;
  $("presentes").textContent=m.length;
  $("faltan").textContent=Math.max(0,people.length-m.length);
  renderHistory();
}
function toggle(name){
  const k=dayKey();
  state[k]=state[k]||{marked:[],savedAt:null};
  state[k].marked=state[k].marked.includes(name)
    ? state[k].marked.filter(x=>x!==name)
    : [...state[k].marked,name];
  saveState(); render();
}
function addPerson(){
  const n=$("personName").value.trim();
  if(!n)return;
  if(!people.some(x=>x.toLowerCase()===n.toLowerCase())) people.push(n);
  savePeople(); $("personName").value=""; $("personDialog").close(); render();
}
function removePerson(i){
  if(confirm(`¿Eliminar "${people[i]}" del listado?`)){
    people.splice(i,1); savePeople(); render();
  }
}
function saveDay(){
  const k=dayKey();
  state[k]=state[k]||{marked:[]};
  state[k].savedAt=new Date().toLocaleString("es-AR");
  saveState();
  $("status").textContent="✓ Control guardado en este teléfono.";
  renderHistory();
}
function clearDay(){
  if(confirm("¿Querés borrar las marcas de este día y turno?")){
    delete state[dayKey()]; saveState(); $("status").textContent=""; render();
  }
}
function renderHistory(){
  const entries=Object.entries(state).filter(([,v])=>v?.savedAt).sort((a,b)=>b[0].localeCompare(a[0]));
  if(!entries.length){$("history").innerHTML='<div class="history-empty">Todavía no hay controles guardados.</div>';return}
  $("history").innerHTML=entries.slice(0,20).map(([k,v])=>{
    const [date,turno]=k.split("_");
    return `<div class="history-item"><b>${date}</b> · ${escapeHtml(turno)}<br><small>${v.marked.length} personas marcadas · ${escapeHtml(v.savedAt)}</small></div>`
  }).join("");
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

$("addBtn").onclick=()=>{$("personDialog").showModal();$("personName").focus()};
$("confirmPerson").onclick=e=>{e.preventDefault();addPerson()};
$("saveBtn").onclick=saveDay;
$("clearBtn").onclick=clearDay;
$("fecha").onchange=render;
$("turno").onchange=render;

window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault(); deferredPrompt=e; $("installBtn").classList.remove("hidden");
});
$("installBtn").onclick=async()=>{
  if(!deferredPrompt)return;
  deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt=null;
  $("installBtn").classList.add("hidden");
};
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js"));
render();